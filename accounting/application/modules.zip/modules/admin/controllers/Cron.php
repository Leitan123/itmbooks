<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cron extends CI_Controller {

    public function expiryReminder() {
        $this->load->model('reload_model', 'model');
        $data = $this->model->getExpiryRemider();
         $api_instance = new NotifyLk\Api\SmsApi();
$user_id = ""; 
$api_key = ""; 

$sender_id = ""; 
$contact_fname = ""; 
$contact_lname = "";  
$contact_email = "";  
$contact_address = "";  
$contact_group = 0;  
$type = null; 
try {
   
    foreach ($data as $row) {
        $message = "Dear Customer, your connection for the {$row->Provider} is going to expire on {$row->ExpiryON}. Please recharge before this date to avoid service interruption. call for recharge : 0768866972 / 0112339920 . Thank you for staying with us! 
"; 
$data = $this->model->UpdateExpiryStatus($row->ReloadId);
$mobile =$row->MobileNo;
if($mobile!= ''){
                    if ($mobile[0] === '0') {
    $mobile = "94".substr($mobile, 1);
}
}
$to = $mobile; 

    $api_instance->sendSMS($user_id, $api_key, $message, $to, $sender_id, $contact_fname, $contact_lname, $contact_email, $contact_address, $contact_group, $type);
        file_put_contents('/home/g45lpenyspna/public_html/jayatha.lk/cron_log.txt', 'Cron executed on '.date('Y-m-d H:i:s').PHP_EOL, FILE_APPEND);
}
} catch (Exception $e) {
    echo 'Exception when calling SmsApi->sendSMS: ', $e->getMessage(), PHP_EOL;
}
    }
}
