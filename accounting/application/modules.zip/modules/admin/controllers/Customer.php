<?php
include_once APPPATH . "modules/admin/core/MY_Controller.php";

class Customer extends MY_Controller
{
    var $page = "customer";
    var $img_width = 600;
    var $img_height = 600;

    function __construct()
    {
        parent::__construct();
        $this->load->model('customer_model', 'model');
        $this->controller = get_class();
    }

    function create()
    {
        $count = $this->model->count_by([]);
        $cus = $count + 1;

        // Generate a five-digit Customer Number
        $CustomerNo = sprintf('%05d', $cus);

        // Generate a random six-digit SID using mt_rand() for PHP 5.6 compatibility
        $Sid = mt_rand(10000, 99999);

        $this->obj = $this->model->get_all_fields();
        $d = [
            'page' => "$this->page/form",
            'obj' => $this->obj,
            'CustomerNo' => $CustomerNo,
            'Sid' => $Sid // Pass the SID to the view
        ];

        $this->_form($d);
    }



    function _form(&$d, $_id = 0)
    {
        $this->form_validation->set_rules("form[CustomerName]", "Customer Name", "required");
     //   $this->form_validation->set_rules("form[MobileNo]", "Mobile No", "required");
     //   $this->form_validation->set_rules("form[Vc]", "VC", "required");

        if ($this->form_validation->run()) {
            $post = $this->input->post('form');

            // Check if the same MobileNo already exists in the database
            $existing = $this->model->check_duplicate_mobileno($post['MobileNo'], $_id);
            if ($existing) {
                $this->session->set_flashdata('notification', [
                    "alert" => "danger",
                    "text" => '<strong>The same MobileNo already exists.</strong>'
                ]);
                redirect(current_url());
            }

            


            // Prepare customer data for insertion or update
            $customer_data = [
                'CustomerNo'   => $post['CustomerNo'],
                'CompanyName' => $post['CompanyName'],
                'CustomerName' => $post['CustomerName'],
                'RegDate'      => $post['RegDate'],
                'Phone'     => $post['Phone'],
                'MobileNo'     => $post['MobileNo'],
                'Address'     => $post['Address'],
                'CustomerType'     => $post['CustomerType'],
                'CreditLimit'     => $post['CreditLimit'],
                'OpeningBalance'     => $post['OpeningBalance'],
            ];

            $this->db->trans_begin();
            if ($_id) {
                $this->model->update($_id, $customer_data); // Update customer data
            } else {
                $post['CreatedDate'] = date("Y-m-d H:i:s");
                $this->model->insert($customer_data); // Insert customer data
            }

            if ($this->db->trans_status() === FALSE) {
                $this->db->trans_rollback();
                $this->session->set_flashdata('notification', [
                    "alert" => "danger",
                    "text" => '<strong>' . (!$_id ? "Creation." : "Update.") . ' Failure !!! </strong>'
                ]);
            } else {
                $this->db->trans_commit();
                $this->session->set_flashdata('notification', [
                    "alert" => "success",
                    "text" => '<strong> Customer Successfully ' . (!$_id ? "Added." : "Updated.") . '</strong>'
                ]);
            }

            redirect(current_url());
        }
        $this->view($d);
    }

    function edit($_id = 0)
    {
        if ($_id) {
            $obj = $this->model->get($_id);
            $d = [
                'page' => "$this->page/form",
                'obj' => $obj,
                'CustomerNo' => $obj->CustomerNo
            ];
            $this->_form($d, $_id);
        } else {
            $this->index();
        }
    }

    function index()
    {
        $d = [
            'page' => "$this->page/index",
            'records' => $this->model->get_all()
        ];
        $this->view($d);
    }

    function delete($_id = 0)
    {
        if ($_id) {
            $this->model->delete($_id);
            if ($this->db->affected_rows() > 0) {
                $this->session->set_flashdata('notification', [
                    "alert" => "success",
                    "text" => '<strong>Record Deleted Successfully.</strong>'
                ]);
            } else {
                $this->session->set_flashdata('notification', [
                    "alert" => "danger",
                    "text" => '<strong>Failed to Delete Record or Record Not Found.</strong>'
                ]);
            }
            redirect(base_url("admin/$this->controller"));
        } else {
            $this->index();
        }
    }

    public function get_customer_details()
    {
        $customerId = $this->input->post('customerId');
        log_message('debug', 'Received customerId: ' . $customerId);  // Debugging log

        if ($customerId) {
            $details = $this->model->get_customer_details($customerId);
            log_message('debug', 'Customer Details: ' . json_encode($details));  // Debugging log
            echo json_encode($details);
        } else {
            echo json_encode(['error' => 'Invalid Customer ID']);
        }
    }





}
?>
