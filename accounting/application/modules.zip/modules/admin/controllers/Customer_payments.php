<?php
include_once APPPATH . "modules/admin/core/MY_Controller.php";

class Customer_payments extends MY_Controller
{
    var $page = "customer_payments";

    function __construct()
    {
        parent::__construct();
        $this->load->model('customer_payments_model', 'model');
        $this->load->model('customer_model', 'customer');
        $this->controller = get_class();
    }

    public function index() {
        $records = $this->model->get_all();
        $d = [
            'page' => "$this->page/index",
            'records' => $records
        ];
        $this->view($d);
    }

    public function create() {
        $this->_form();
    }

    function _form($data = []) {
        // Load customers
        $data['customers'] = $this->customer->get_all();

        // Set form validation rules
        $this->form_validation->set_rules("form[CustomerId]", "Customer", "required");
        $this->form_validation->set_rules("form[PaidAmount]", "Paid Amount", "required|numeric");
        $this->form_validation->set_rules("form[PaymentDate]", "Payment Date", "required");
        $this->form_validation->set_rules("form[PaymentMethod]", "Payment Method", "required");

        if ($this->form_validation->run()) {
            $this->save_payment(); // Call save function
            return; // Prevent further execution
        }

        // Pass data to the view
        $this->view([
            'page' => "$this->page/form",
            'customers' => $data['customers'],
        ]);
    }

    public function save_payment() {
    $data = $this->input->post('form');

    // Validate customer existence
    $customer = $this->db->where('CustomerId', $data['CustomerId'])->get('customer')->row();
    if (!$customer) {
        $this->session->set_flashdata('notification', [
            "alert" => "danger",
            "text" => '<strong>Invalid Customer ID.</strong>'
        ]);
        redirect('admin/Customer_payments');
        return;
    }

    // Fetch total sale amount for the customer
    $totalSaleAmount = $this->db->select_sum('TotalSaleAmount')
        ->where('CustomerId', $data['CustomerId'])
        ->where('IsDeleted', 0) // Exclude deleted sales
        ->get('sales')
        ->row()
        ->TotalSaleAmount;

    if (!$totalSaleAmount) {
        $this->session->set_flashdata('notification', [
            "alert" => "danger",
            "text" => '<strong>No sales found for this customer.</strong>'
        ]);
        redirect('admin/Customer_payments');
        return;
    }

    // Get the SaleID (if needed for a specific sales)
    $saleID = $this->db->select('SaleID')
        ->where('CustomerId', $data['CustomerId'])
        ->where('IsDeleted', 0)  // Make sure it's not deleted
        ->limit(1)  // Assuming you want to get the first available sales ID for the vendor
        ->get('sales')
        ->row()
        ->SaleID;

    // If no sales found, show an error
    if (!$saleID) {
        $this->session->set_flashdata('notification', [
            "alert" => "danger",
            "text" => '<strong>No valid sales found for this vendor.</strong>'
        ]);
        redirect('admin/Customer_payments');
        return;
    }

    // Fetch total paid amount for the customer
    $totalPaid = $this->db->select_sum('PaidAmount')
        ->where('CustomerId', $data['CustomerId'])
        ->where('IsDeleted', 0) // Exclude deleted payments
        ->get('customer_payments')
        ->row()
        ->PaidAmount;

    // Calculate PaymentDue
    $paymentDue = ($totalSaleAmount ? $totalSaleAmount : 0) 
                - ($totalPaid ? $totalPaid : 0) 
                - ($data['PaidAmount'] ? $data['PaidAmount'] : 0);

    // Calculate CreditBalance
    $creditBalance = $customer->CreditLimit - $paymentDue;

    // Prepare payment data

    $paymentData = [
        'CustomerId' => $data['CustomerId'],
        'SaleID' => $saleID,  // Correct variable name
        'PaidAmount' => $data['PaidAmount'],
        'PaymentDue' => $paymentDue,
        'CreditBalance' => $creditBalance,
        'PaymentDate' => $data['PaymentDate'],
        'PaymentMethod' => $data['PaymentMethod'],
        'ChequeNumber' => $data['ChequeNumber'],
        'ChequeDate' => $data['ChequeDate'],
    ];

    // Save payment data
    $isSaved = $this->db->insert('customer_payments', $paymentData);

    if ($isSaved) {
        $this->session->set_flashdata('notification', [
            "alert" => "success",
            "text" => '<strong>Payment added successfully!</strong>'
        ]);
    } else {
        $this->session->set_flashdata('notification', [
            "alert" => "danger",
            "text" => '<strong>Failed to add payment.</strong>'
        ]);
    }

    redirect('admin/Customer_payments');
}


    public function get_total_due_amount($customerId)
    {   

        // Fetch customer details
        $customer = $this->db->where('CustomerId', $customerId)->get('customer')->row();

        if (!$customer) {
            echo json_encode(['error' => 'Invalid Customer']);
            return;
        }

        // Get total paid amount for the customer
        $totalPaid = $this->db->select_sum('PaidAmount')
            ->where('CustomerId', $customerId)
            ->where('IsDeleted', 0) // Exclude deleted payments
            ->get('customer_payments')
            ->row()
            ->PaidAmount;

        // Get total sales amount for the customer
        $totalSales = $this->db->select_sum('TotalSaleAmount')
            ->where('CustomerId', $customerId)
            ->where('IsDeleted', 0) // Exclude deleted sales
            ->get('sales')
            ->row()
            ->TotalSaleAmount;

        // Handle null values with default 0
        $totalPaid = $totalPaid ? $totalPaid : 0;
        $totalSales = $totalSales ? $totalSales : 0;

        // Calculate payment due
        $paymentDue = $totalSales - $totalPaid;

        // Ensure PaymentDue is not negative
        $paymentDue = max(0, $paymentDue);

        // Calculate PaymentDue and CreditBalance
        $paymentDue = ($totalSales ?: 0) - ($totalPaid ?: 0);
        $creditBalance = $customer->CreditLimit - $paymentDue;

        // Return as JSON
        echo json_encode([
            'PaymentDue' => $paymentDue,
            'CreditBalance' => $creditBalance
        ]);
    }


    private function get_total_paid($customerId) {
        $totalPaid = $this->db->select_sum('PaidAmount')
            ->where('CustomerId', $customerId)
            ->where('IsDeleted', 0) // Exclude deleted payments
            ->get('customer_payments')
            ->row()
            ->PaidAmount;

        return $totalPaid ? $totalPaid : 0;
    }

    public function balance_sheet() {
        $records = $this->model->get_all_customers_with_due();
        $d = [
            'page' => "$this->page/balance_sheet",
            'records' => $records
        ];
        $this->view($d);
    }

    function edit($_id = 0) {
        if ($_id) {
            $obj = $this->model->get($_id);
            $d = [
                'page' => "$this->page/form",
                'obj' => $obj
            ];
            $this->_form($d, $_id);
        } else {
            $this->index();
        }
    }

    function delete($_id = 0) {
        if ($_id) {
            // Update the IsDeleted field instead of deleting the record
            $this->db->set('IsDeleted', 1)
                     ->where('PaymentId', $_id)
                     ->update('customer_payments');

            if ($this->db->affected_rows() > 0) {
                $this->session->set_flashdata('notification', [
                    "alert" => "success",
                    "text" => '<strong>Record Marked as Deleted Successfully.</strong>'
                ]);
            } else {
                $this->session->set_flashdata('notification', [
                    "alert" => "danger",
                    "text" => '<strong>Failed to Mark as Deleted or Record Not Found.</strong>'
                ]);
            }
            redirect(base_url("admin/$this->controller"));
        } else {
            $this->index();
        }
    }

    public function print_receipt($paymentID) {
        // Load the model
        $this->load->model('customer_payments_model');

        // Fetch specific payment data
        $data['customer_payments'] = $this->customer_payments_model->get_payment_by_id($paymentID);

        // Check if the record exists
        if (!$data['customer_payments']) {
            show_404(); // Show 404 if not found
        }

        // Load the view for printing receipt
        $this->load->view('admin/pages/customer_payments/print_receipt', $data);
    }
}
?>
