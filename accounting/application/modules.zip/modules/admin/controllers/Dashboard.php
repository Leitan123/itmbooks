<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    public function __construct() {
        parent::__construct();
        // Load any necessary models or helpers here
        $this->load->model('Reload_model');  // Load the reload model
    }

    // This is the index function where you will load the dashboard
    public function index() {
        $this->load->model('Reload_model');  // Load the Reload model

        // Fetch reload records from the model
        $data['reloadRecords'] = $this->Reload_model->get_reload_data(); 

        // Load the dashboard view and pass the reload data
        $this->load->view('admin/dashboard', $data);
    }
}
