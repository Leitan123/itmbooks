<?php
class Home extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        // Load the required models
        $this->load->model('user_model', 'user');
        $this->load->model('Customer_payments_model');
        $this->load->model('Vendor_payments_model');
        $this->load->model('Customer_model');
        $this->load->model('Sales_model');
    }

    public function index()
    {
        if (!$this->session->has_userdata('user')) {
            $data['error'] = "";
            $this->form_validation->set_rules('username', '', 'required');
            $this->form_validation->set_rules('password', '', 'required');

            if ($this->form_validation->run()) {
                $user = $this->user->get_by([
                    'Username' => $this->input->post('username'),
                    'Password' => sha1($this->input->post('password')) // Ensure password hashing
                ]);

                if ($user) {
                    $time = time(); 
	            	$login_token = sha1($user->UserId.$user->Password.$time); 
                    $this->session->set_userdata("user", $user);
                    
                    $array = [
				'login' => true, 
				'login_token' => $login_token,
				'logged' => [
					'id' => $user->UserId,
					'time' => $time,
				]
			];
			$this->session->set_userdata( $array );
                    
           
                    if ($this->session->userdata('url')) {
                        redirect($this->session->userdata('url'));
                    }
                    redirect(base_url('admin'));
                } else {
                    $data['error'] = "Invalid Username or Password";
                }
            }
            $this->load->view('login', $data);
        } else {
            if ($this->session->userdata('url')) {
                redirect($this->session->userdata('url'));
            }

            $data = [
                "user" => $this->session->userdata('user'),
                "total_customers" => $this->Customer_model->get_total_customers()
            ];
            $this->load->view('dashboard', $data);
        }
    }

    public function dashboard()
    {
        // Get today's sales
        $data['todays_sales'] = $this->Customer_payments_model->get_all_customers_with_due();

        // Get customers with due payments
        $data['customers_with_due'] = $this->Customer_payments_model->get_all_customers_with_due();
        
        // Get vendors with due payments
        $data['vendors_with_due'] = $this->Vendor_payments_model->get_all_vendors_with_due();

        // Get total customers
        $data['total_customers'] = $this->Customer_model->get_total_customers();

        // Load the dashboard view with the data
        $this->load->view('admin/dashboard', $data);
    }

    public function logout()
    {
        $this->session->sess_destroy();
        echo json_encode(['logout' => true]);
    }
}
