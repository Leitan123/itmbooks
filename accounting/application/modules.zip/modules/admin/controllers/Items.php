<?php
include_once APPPATH . "modules/admin/core/MY_Controller.php";

class Items extends MY_Controller
{
    var $page = "items";
    var $img_width = 600;
    var $img_height = 600;

    function __construct()
    {
        parent::__construct();
        $this->load->model('items_model', 'model');
        $this->load->model('brand_model'); // Ensure the brand model is loaded
        $this->controller = get_class($this);
    }

    function create()
    {
        $this->obj = $this->model->get_all_fields();
        $categories = $this->model->get_categories(); // Load categories
        $brands = $this->model->get_brand(); // Load brands

        $data = [
            'page' => "{$this->page}/form",
            'obj' => $this->obj,
            'categories' => $categories,
            'brands' => $brands,
        ];

        $this->_form($data);
    }

    function _form(&$data, $_id = 0)
    {
        $this->form_validation->set_rules("form[ItemName]", "Item Name", "required");

        if ($this->form_validation->run()) {
            $post = $this->input->post('form');

            $item_data = [
                'ItemName' => isset($post['ItemName']) ? $post['ItemName'] : '',
                'ItemDescription' => isset($post['ItemDescription']) ? $post['ItemDescription'] : '',
                'PurchasePrice' => isset($post['PurchasePrice']) ? $post['PurchasePrice'] : 0,
                'SellingPrice' => isset($post['SellingPrice']) ? $post['SellingPrice'] : 0,
                'Stock' => isset($post['Stock']) ? $post['Stock'] : 0,
                'CategoryID' => isset($post['CategoryID']) ? $post['CategoryID'] : 0,
                'CategoryName' => isset($post['CategoryName']) ? $post['CategoryName'] : '',
                'BrandID' => isset($post['BrandID']) ? $post['BrandID'] : 0,
                'BrandName' => isset($post['BrandName']) ? $post['BrandName'] : '',
                'UpdatedAt' => date('Y-m-d H:i:s'),
            ];

            if (!$_id) {
                $item_data['CreatedAt'] = date('Y-m-d H:i:s');
                $item_data['IsDeleted'] = 0;
            }

            $this->db->trans_begin();

            if ($_id) {
                $this->model->update($_id, $item_data);
            } else {
                $this->model->insert($item_data);
            }

            if ($this->db->trans_status() === FALSE) {
                $this->db->trans_rollback();
                $this->session->set_flashdata('notification', [
                    "alert" => "danger",
                    "text" => 'Failed to save item. Please try again.'
                ]);
            } else {
                $this->db->trans_commit();
                $this->session->set_flashdata('notification', [
                    "alert" => "success",
                    "text" => 'Item saved successfully.'
                ]);
            }

            redirect(current_url());
        }

        $this->view($data);
    }

    function edit($_id = 0)
    {
        if ($_id) {
            $obj = $this->model->get($_id);
            if (!$obj) {
                $this->session->set_flashdata('notification', [
                    "alert" => "danger",
                    "text" => 'Record not found.'
                ]);
                redirect(base_url("admin/$this->controller"));
            }

            $categories = $this->model->get_categories();
            $brands = $this->model->get_brand();

            $data = [
                'page' => "{$this->page}/form",
                'obj' => $obj,
                'categories' => $categories,
                'brands' => $brands,
            ];

            $this->_form($data, $_id);
        } else {
            $this->index();
        }
    }


    

    function index()
    {
        $data = [
            'page' => "{$this->page}/index",
            'records' => $this->model->get_items_with_categories(),
        ];
        $this->view($data);
    }

    function delete($_id = 0)
    {
        if ($_id) {
            $this->model->delete($_id);
            if ($this->db->affected_rows() > 0) {
                $this->session->set_flashdata('notification', [
                    "alert" => "success",
                    "text" => 'Record deleted successfully.'
                ]);
            } else {
                $this->session->set_flashdata('notification', [
                    "alert" => "danger",
                    "text" => 'Failed to delete record or record not found.'
                ]);
            }
            redirect(base_url("admin/$this->controller"));
        } else {
            $this->index();
        }
    }

    public function get_brands_by_category()
    {
        $category_id = $this->input->post('category_id');

        if ($category_id) {
            $brands = $this->brand_model->get_brands_by_category($category_id);
            echo json_encode($brands);
        } else {
            echo json_encode([]);
        }
    }
}
?>
