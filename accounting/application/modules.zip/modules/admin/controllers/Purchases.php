<?php
include_once APPPATH . "modules/admin/core/MY_Controller.php";

class Purchases extends MY_Controller
{
    var $page = "purchases";

    function __construct()
    {
        parent::__construct();
        $this->load->model('purchases_model', 'model');
        $this->load->model('purchase_items_model', 'model');
        $this->load->model('items_model', 'items');
        $this->load->model('vendor_model', 'vendor');
        $this->load->model('categories_model', 'categories');
        $this->load->model('brand_model', 'brand');
        $this->controller = get_class();
    }

    public function index() {
        $records = $this->model->get_all();
        $d = [
            'page' => "$this->page/index",
            'records' => $records
        ];
        $this->view($d);
    }


    public function edit($_id = 0)
    {
        if ($_id) {
            $data['purchases'] = $this->model->get_purchase_by_id($_id);
            $data['purchase_items'] = $this->vendor->get_all();
            $data['vendors'] = $this->vendor->get_all();
            $data['categories'] = $this->categories->get_all();
            $data['brand'] = $this->brand->get_all();
            $data['items'] = $this->items->get_all();

            $this->_form($data, $_id);
        } else {
            $this->index();
        }
    }




    function create() {
        $this->_form();
    }

    function _form($data = [], $id = null)
    {
        if (empty($data['vendors'])) {
            $data['vendors'] = $this->vendor->get_all();
        }

        if (empty($data['categories'])) {
            $data['categories'] = $this->categories->get_all();
        }

        if (empty($data['brand'])) {
            $data['brand'] = $this->brand->get_all();
        }

        if (empty($data['items'])) {
            $data['items'] = $this->items->get_all();
        }

        if ($id) {
            $data['purchase'] = $this->model->get_purchase_by_id($id);
        } else {
            $data['purchase'] = null;
        }

        $this->form_validation->set_rules("form[VendorID]", "Vendor", "required");
        $this->form_validation->set_rules("form[PurchaseDate]", "Purchase Date", "required");
        $this->form_validation->set_rules("form[items]", "Items", "required");

        if ($this->form_validation->run()) {
            $this->save_purchase();
            return;
        }

        $this->view([
            'page' => "$this->page/form",
            'vendors' => $data['vendors'],
            'items' => $data['items'],
            'categories' => $data['categories'],
            'brand' => $data['brand'],
            'purchase' => $data['purchase']
        ]);
    }


    function delete($_id = 0) {
        if ($_id) {
            $this->model->delete($_id);
            if ($this->db->affected_rows() > 0) {
                $this->session->set_flashdata('notification', [
                    "alert" => "success",
                    "text" => '<strong>Record Deleted Successfully.</strong>'
                ]);
            } else {
                $this->session->set_flashdata('notification', [
                    "alert" => "danger",
                    "text" => '<strong>Failed to Delete Record or Record Not Found.</strong>'
                ]);
            }
            redirect(base_url("admin/$this->controller"));
        } else {
            $this->index();
        }
    }

    // Fetch items by category, returned as JSON
    public function get_items_by_category($CategoryID) {
        $items = $this->db->where('CategoryID', $CategoryID)
                          ->get('items')
                          ->result();

        echo json_encode($items); // Return JSON for use in AJAX
    }


    // Save multiple items for a purchase
    public function save_purchase() {
        $data = $this->input->post('form');
        $totalPurchaseAmount = 0; // Initialize total amount

        // Log submitted data
        log_message('debug', 'Submitted Purchase Data: ' . print_r($data, true));

        // Check if vendor exists
        $vendorExists = $this->db->where('VendorID', $data['VendorID'])->get('vendor')->num_rows() > 0;

        if (!$vendorExists) {
            $this->session->set_flashdata('notification', [
                "alert" => "danger",
                "text" => '<strong>Invalid Vendor ID.</strong>'
            ]);
            redirect('admin/Purchases');
            return;
        }

        // Prepare initial purchase data
        $purchaseData = [
            'VendorID' => $data['VendorID'],
            'PurchaseDate' => $data['PurchaseDate'],
            'TotalPurchaseAmount' => 0, // We'll calculate this later
            'CreatedAt' => date('Y-m-d H:i:s'),
            'UpdatedAt' => date('Y-m-d H:i:s'),
        ];

        // Insert into purchases table
        if ($this->db->insert('purchases', $purchaseData)) {
            $purchaseID = $this->db->insert_id(); // Get the last inserted PurchaseID

            // Save purchase items
            foreach ($data['items'] as $item) {
                // Ensure CategoryID is included in the purchase item data
                $purchaseItemData = [
                    'PurchaseID' => $purchaseID,
                    'ItemID' => $item['ItemID'], // Assuming you're passing ItemID
                    'Quantity' => $item['Quantity'],
                    'PurchasePrice' => $item['PurchasePrice'],
                    'TotalAmount' => $item['Quantity'] * $item['PurchasePrice'], // Calculate total amount
                ];

                // Update total purchase amount
                $totalPurchaseAmount += $purchaseItemData['TotalAmount'];

                // Insert purchase items into purchase_items table
                if (!$this->db->insert('purchase_items', $purchaseItemData)) {
                    log_message('error', 'Failed to insert purchase item: ' . print_r($this->db->error(), true));
                }
            }

            // Now update the TotalPurchaseAmount in the purchases table
            $this->db->where('PurchaseID', $purchaseID);
            $this->db->update('purchases', ['TotalPurchaseAmount' => $totalPurchaseAmount]);

            // Log the result of the update
            log_message('debug', 'Updated TotalPurchaseAmount: ' . $totalPurchaseAmount);

            // Redirect to purchases list or show success message
            $this->session->set_flashdata('notification', [
                "alert" => "success",
                "text" => '<strong>Purchase added successfully!</strong>'
            ]);
        } else {
            log_message('error', 'Failed to insert purchase: ' . print_r($this->db->error(), true));
            $this->session->set_flashdata('notification', [
                "alert" => "danger",
                "text" => '<strong>Failed to add purchase.</strong>'
            ]);
        }

        redirect('admin/Purchases');
    }


    public function stock() {
        // Fetch stock data from the model
        $stockData = $this->model->get_stock_report();

        // Pass the stock data to the view
        $this->view([
            'page' => 'purchases/stock',
            'stockData' => $stockData
        ]);
    }




    public function form() {
        // Load necessary models
        $this->load->model('Purchase_model');
        $this->load->model('Vendor_model');
        $this->load->model('Category_model');
        $this->load->model('Brand_model');

        // Fetch data for the form
        $data['vendors'] = $this->Vendor_model->get_all_vendors();
        $data['categories'] = $this->Category_model->get_all_categories();
        $data['brand'] = $this->Brand_model->get_all_brand();

        // Load the form view
        $this->load->view('admin/pages/purchases/form', $data);
    }

    public function save() {
        // Gather form data
        $vendorID = $this->input->post('vendor_id');
        $items = $this->input->post('item_ids');
        $quantities = $this->input->post('quantities');
        $prices = $this->input->post('prices');
        $totalAmount = $this->input->post('total_amount');

        // Save purchase details
        $purchaseID = $this->Purchase_model->save_purchase($vendorID, $totalAmount);

        // Save each purchased item
        foreach ($items as $index => $itemID) {
            $this->Purchase_model->save_purchase_item($purchaseID, $itemID, $quantities[$index], $prices[$index]);
        }

        // Redirect or show success message
        redirect('admin/purchases');
    }

    public function getItemsByCategory() {
        $categoryID = $this->input->post('category_id');
        $this->load->model('Item_model');
        $items = $this->Item_model->get_items_by_category($categoryID);

        $options = '<option value="">Select Item</option>';
        foreach ($items as $item) {
            $options .= '<option value="' . $item->ItemID . '" data-price="' . $item->Price . '">' . $item->ItemName . '</option>';
        }

        echo $options;
    }


    public function print_purchase($purchaseID)
    {
        // Load the Sale details
        $this->load->model('Purchases_model');
        $purchase = $this->Purchases_model->get_purchase_by_id($purchaseID);  // Ensure this returns purchase data
        $items = $this->Purchases_model->get_purchase_items($purchaseID); // Ensure this fetches purchase items related to the sale

        // Check if purchase and items are retrieved
        if ($purchase && $items) {
            $purchase->items = $items; // Add the items to the purchase object
        } else {
            $purchase->items = []; // Fallback if no items are found
        }

        // Load the view
        $data['purchases'] = $purchase;  // Ensure that this array contains 'sales'
        $this->load->view('admin/pages/purchases/print_purchase', $data);
    }


}
?>
