<?php
include_once APPPATH . "modules/admin/core/MY_Controller.php";

class Sales extends MY_Controller
{
    var $page = "sales";

    function __construct()
    {
        parent::__construct();
        $this->load->model('sales_model', 'model');
        $this->load->model('items_model', 'items');
        $this->load->model('customer_model', 'customer');
        $this->load->model('categories_model', 'categories');
        $this->controller = get_class();
    }

    // Display the sales index page
    public function index()
    {
        $records = $this->model->get_all();
        $d = [
            'page' => "$this->page/index",
            'records' => $records
        ];
        $this->view($d);
    }



    // Edit a specific sale by ID
    public function edit($_id = 0)
    {
        if ($_id) {
            $data['sales'] = $this->model->get_sale_by_id($_id);
            $data['customers'] = $this->customer->get_all();
            $data['categories'] = $this->categories->get_all();
            $data['items'] = $this->items->get_all(); // Fetch all items

            // Pass the data to the _form method
            $this->_form($data, $_id);
        } else {
            $this->index();
        }
    }

    // Create a new sale
    function create()
    {
        $this->_form();
    }

    // Handle the sale form (create/edit)
    function _form($data = [], $id = null)
    {
        // Load customers, items, and categories if not already passed
        if (empty($data['customers'])) {
            $data['customers'] = $this->customer->get_all();
        }

        if (empty($data['categories'])) {
            $data['categories'] = $this->categories->get_all();
        }

        if (empty($data['items'])) {
            $data['items'] = $this->items->get_all();
        }

        // Fetch existing sale data if editing
        if ($id) {
            $data['sale'] = $this->model->get_sale_by_id($id);
        } else {
            $data['sale'] = null;
        }

        // Set form validation rules
        $this->form_validation->set_rules("form[CustomerId]", "Customer", "required");
        $this->form_validation->set_rules("form[SaleDate]", "Sale Date", "required");
        $this->form_validation->set_rules("form[items]", "Items", "required");

        if ($this->form_validation->run()) {
            $this->save_sale(); // Call save function
            return; // Prevent further execution
        }

        // Pass data to the view
        $this->view([
            'page' => "$this->page/form",
            'customers' => $data['customers'],
            'items' => $data['items'],
            'categories' => $data['categories'],
            'sale' => $data['sale'] // Pass the sale data
        ]);
    }

    // Delete a sale by ID
    function delete($_id = 0)
    {
        if ($_id) {
            $this->model->delete($_id);
            if ($this->db->affected_rows() > 0) {
                $this->session->set_flashdata('notification', [
                    "alert" => "success",
                    "text" => '<strong>Record Deleted Successfully.</strong>'
                ]);
            } else {
                $this->session->set_flashdata('notification', [
                    "alert" => "danger",
                    "text" => '<strong>Failed to Delete Record or Record Not Found.</strong>'
                ]);
            }
            redirect(base_url("admin/$this->controller"));
        } else {
            $this->index();
        }
    }

    // Fetch items by category, returned as JSON
    public function get_items_by_category($categoryId)
    {
        $items = $this->db->where('CategoryID', $categoryId)
                          ->get('items')
                          ->result();

        echo json_encode($items); // Return JSON for use in AJAX
    }


    // Save multiple items for a sale
    public function save_sale() {
        $data = $this->input->post('form');
        $totalSaleAmount = 0; // Initialize total amount

        // Log submitted data
        log_message('debug', 'Submitted Sale Data: ' . print_r($data, true));

        // Check if customer exists
        $customerExists = $this->db->where('CustomerId', $data['CustomerId'])->get('customer')->num_rows() > 0;

        if (!$customerExists) {
            $this->session->set_flashdata('notification', [
                "alert" => "danger",
                "text" => '<strong>Invalid Customer ID.</strong>'
            ]);
            redirect('admin/Sales');
            return;
        }

        // Prepare initial sale data
        $saleData = [
            'CustomerId' => $data['CustomerId'],
            'SaleDate' => $data['SaleDate'],
            'TotalSaleAmount' => 0, // We'll calculate this later
            'CreatedAt' => date('Y-m-d H:i:s'),
            'UpdatedAt' => date('Y-m-d H:i:s'),
        ];

        // Insert into sales table
        if ($this->db->insert('sales', $saleData)) {
            $saleID = $this->db->insert_id(); // Get the last inserted SaleID

            // Save sale items
            foreach ($data['items'] as $item) {
                // Ensure CategoryID is included in the sale item data
                $saleItemData = [
                    'SaleID' => $saleID,
                    'ItemID' => $item['ItemID'], // Assuming you're passing ItemID
                    'Quantity' => $item['Quantity'],
                    'SalePrice' => $item['SalePrice'],
                    'TotalAmount' => $item['Quantity'] * $item['SalePrice'], // Calculate total amount
                    'CategoryID' => $item['CategoryID'] // Add CategoryID here
                ];

                // Update total sale amount
                $totalSaleAmount += $saleItemData['TotalAmount'];

                // Insert sale items into sale_items table
                if (!$this->db->insert('sale_items', $saleItemData)) {
                    log_message('error', 'Failed to insert sale item: ' . print_r($this->db->error(), true));
                }
            }

            // Now update the TotalSaleAmount in the sales table
            $this->db->where('SaleID', $saleID);
            $this->db->update('sales', ['TotalSaleAmount' => $totalSaleAmount]);

            // Log the result of the update
            log_message('debug', 'Updated TotalSaleAmount: ' . $totalSaleAmount);

            // Redirect to sales list or show success message
            $this->session->set_flashdata('notification', [
                "alert" => "success",
                "text" => '<strong>Sale added successfully!</strong>'
            ]);
        } else {
            log_message('error', 'Failed to insert sale: ' . print_r($this->db->error(), true));
            $this->session->set_flashdata('notification', [
                "alert" => "danger",
                "text" => '<strong>Failed to add sale.</strong>'
            ]);
        }

        redirect('admin/Sales');
    }



    // Display stock report
    public function stock()
    {
        // Fetch stock data from the model
        $stockData = $this->model->get_stock_report();

        // Pass the stock data to the view
        $this->view([
            'page' => 'sales/stock',
            'stockData' => $stockData
        ]);
    }

    // Print invoice for a specific sale
    public function print_invoice($saleID)
    {
        // Load the Sale details
        $sale = $this->model->get_sale_by_id($saleID);  // Ensure this returns sale data
        $items = $this->model->get_sale_items($saleID); // Ensure this fetches sale items related to the sale

        // Check if sale and items are retrieved
        if ($sale && $items) {
            $sale->items = $items; // Add the items to the sale object
        } else {
            $sale->items = []; // Fallback if no items are found
        }

        // Load the view
        $data['sales'] = $sale;  // Ensure that this array contains 'sales'
        $this->load->view('admin/pages/sales/print_invoice', $data);
    }
    


    public function get_customer_details()
    {
        $customerId = $this->input->post('customerId');
        if ($customerId) {
            $this->load->model('Customer_model');
            $this->load->model('Customer_payments_model');

            // Fetch CreditLimit from the customer table
            $customer = $this->Customer_model->get_by_id($customerId);

            // Fetch CreditBalance from the customer_payments table
            $creditBalance = $this->Customer_payments_model->get_credit_balance($customerId);

            if ($customer) {
                echo json_encode([
                    'error' => false,
                    'CustomerType' => $customer->CustomerType,
                    'CreditLimit' => $customer->CreditLimit,
                    'CreditBalance' => $creditBalance,
                ]);
            } else {
                echo json_encode(['error' => 'Customer not found']);
            }
        } else {
            echo json_encode(['error' => 'Invalid Customer ID']);
        }
    }

}
