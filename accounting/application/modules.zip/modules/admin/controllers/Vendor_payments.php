<?php
include_once APPPATH . "modules/admin/core/MY_Controller.php";

class Vendor_payments extends MY_Controller
{
    var $page = "vendor_payments";

    function __construct()
    {
        parent::__construct();
        $this->load->model('vendor_payments_model', 'model');
        $this->load->model('vendor_model', 'vendor');
        $this->controller = get_class();
    }

    public function index() {
        $records = $this->model->get_all();
        $d = [
            'page' => "$this->page/index",
            'records' => $records
        ];
        $this->view($d);
    }

    public function create() {
        $this->_form();
    }

    function _form($data = []) {
        // Load vendors
        $data['vendors'] = $this->vendor->get_all();

        // Set form validation rules
        $this->form_validation->set_rules("form[VendorID]", "Vendor", "required");
        $this->form_validation->set_rules("form[PaidAmount]", "Paid Amount", "required|numeric");
        $this->form_validation->set_rules("form[PaymentDate]", "Payment Date", "required");
        $this->form_validation->set_rules("form[PaymentMethod]", "Payment Method", "required");

        if ($this->form_validation->run()) {
            $this->save_payment(); // Call save function
            return; // Prevent further execution
        }

        // Pass data to the view
        $this->view([
            'page' => "$this->page/form",
            'vendors' => $data['vendors'],
        ]);
    }

    public function save_payment() {
    $data = $this->input->post('form');

    // Check if vendor exists and fetch TotalPurchaseAmount
    $vendor = $this->db->where('VendorID', $data['VendorID'])->get('vendor')->row();
    if (!$vendor) {
        $this->session->set_flashdata('notification', [
            "alert" => "danger",
            "text" => '<strong>Invalid Vendor ID.</strong>'
        ]);
        redirect('admin/Vendor_payments');
        return;
    }

    // Get TotalPurchaseAmount
    $totalPurchaseAmount = $this->db->select('TotalPurchaseAmount')
        ->where('VendorID', $data['VendorID'])
        ->get('purchases')
        ->row()
        ->TotalPurchaseAmount;

    // Get the PurchaseID (if needed for a specific purchase)
    $purchaseID = $this->db->select('PurchaseID')
        ->where('VendorID', $data['VendorID'])
        ->where('IsDeleted', 0)  // Make sure it's not deleted
        ->limit(1)  // Assuming you want to get the first available purchase ID for the vendor
        ->get('purchases')
        ->row()
        ->PurchaseID;

    // If no purchase found, show an error
    if (!$purchaseID) {
        $this->session->set_flashdata('notification', [
            "alert" => "danger",
            "text" => '<strong>No valid purchase found for this vendor.</strong>'
        ]);
        redirect('admin/Vendor_payments');
        return;
    }

    // Calculate PaymentDue
    $paymentDue = $totalPurchaseAmount - $data['PaidAmount'];

    // Prepare payment data
    $paymentData = [
        'VendorID' => $data['VendorID'],
        'PurchaseID' => $purchaseID,  // Include PurchaseID
        'PaidAmount' => $data['PaidAmount'],
        'PaymentDue' => $paymentDue,
        'PaymentDate' => $data['PaymentDate'], // Add Payment Date
        'PaymentMethod' => $data['PaymentMethod'], // Add Payment Method
        'ChequeNumber' => $data['ChequeNumber'],
        'ChequeDate' => $data['ChequeDate'],
    ];

    // Save payment data
    if ($this->model->insert($paymentData)) {
        $this->session->set_flashdata('notification', [
            "alert" => "success",
            "text" => '<strong>Payment added successfully!</strong>'
        ]);
    } else {
        $this->session->set_flashdata('notification', [
            "alert" => "danger",
            "text" => '<strong>Failed to add payment.</strong>'
        ]);
    }

    redirect('admin/Vendor_payments');
}



    // Fetch TotalSaleAmount based on selected vendor
    public function get_total_due_amount($vendorId) {
        // Fetch total paid amount
        $queryPaid = $this->db->select_sum('PaidAmount')
            ->where('VendorID', $vendorId)
            ->where('IsDeleted', 0) // Exclude deleted payments
            ->get('vendor_payments');
        $totalPaid = $queryPaid->row() ? $queryPaid->row()->PaidAmount : 0;

        // Fetch total purchase amount
        $queryPurchases = $this->db->select_sum('TotalPurchaseAmount')
            ->where('VendorID', $vendorId)
            ->where('IsDeleted', 0) // Exclude deleted purchases
            ->get('purchases');
        $totalPurchases = $queryPurchases->row() ? $queryPurchases->row()->TotalPurchaseAmount : 0;

        // Calculate PaymentDue
        $paymentDue = $totalPurchases - $totalPaid;

        // Ensure no negative values
        if ($paymentDue < 0) {
            $paymentDue = 0;
        }

        // Send the response as JSON
        echo json_encode(['PaymentDue' => $paymentDue]);
    }




    private function get_total_paid($vendorId) {
        $totalPaid = $this->db->select_sum('PaidAmount')
            ->where('VendorID', $vendorId)
            ->get('vendor_payments')
            ->row()
            ->PaidAmount;

        return $totalPaid ? $totalPaid : 0;
    }


    public function balance_sheet() {
        $records = $this->model->get_all_vendors_with_due();
        $d = [
            'page' => "$this->page/balance_sheet",
            'records' => $records
        ];
        $this->view($d);
    }


    function edit($_id = 0)
    {
        if ($_id) {
            $obj = $this->model->get($_id);
            $d = [
                'page' => "$this->page/form",
                'obj' => $obj
            ];
            $this->_form($d, $_id);
        } else {
            $this->index();
        }
    }


    function delete($_id = 0)
    {
        if ($_id) {
            $this->model->delete($_id);
            if ($this->db->affected_rows() > 0) {
                $this->session->set_flashdata('notification', [
                    "alert" => "success",
                    "text" => '<strong>Record Deleted Successfully.</strong>'
                ]);
            } else {
                $this->session->set_flashdata('notification', [
                    "alert" => "danger",
                    "text" => '<strong>Failed to Delete Record or Record Not Found.</strong>'
                ]);
            }
            redirect(base_url("admin/$this->controller"));
        } else {
            $this->index();
        }
    }



    
}

?>
