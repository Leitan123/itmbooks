<?php $this->view('includes/header_start.php'); ?>
<!-- extra css start -->
<link href="<?= base_url('assets/css/dashboard.css') ?>" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css"/>
<link href="<?= base_url("assets/plugins/datatables/dataTables.bootstrap4.min.css") ?>" rel="stylesheet" type="text/css"/>
<link href="<?= base_url("assets/plugins/datatables/buttons.bootstrap4.min.css") ?>" rel="stylesheet" type="text/css"/>
<link href="<?= base_url("assets/plugins/datatables/responsive.bootstrap4.min.css") ?>" rel="stylesheet" type="text/css"/>
<!-- extra css end -->
<?php $this->view('includes/header_end.php'); ?>


<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
    <div class="content">
        <div class="container">

            <!-- Start Page Title -->

            <div class="row">
                <div class="col-xs-12">
                    <div class="page-title-box">
                        <h4 class="page-title">Dashboard</h4>
                        <ol class="breadcrumb p-0">
                            <li>
                                <a href="<?= base_url('admin') ?>"><?= isset($title) ? $title : 'IT MARTX' ?></a>
                            </li>
                            <li class="active">
                                Dashboard
                            </li>
                        </ol>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <!-- end row -->

            <!-- Metrics Cards -->
            <?php
                $totalSales = 0;
                $totalPaidAmount = 0;
                $totalDueAmount = 0;
                $totalExpenses = 0;

                // Retrieve customers' payments data
                $customers = $this->Customer_payments_model->get_all_customers_with_due();
                // Retrieve vendors' payments data
                $vendors = $this->Vendor_payments_model->get_all_vendors_with_due();

                // Calculate totals for customers
                foreach ($customers as $customer) {
                    $totalSales += $customer->TotalSaleAmount;
                    $totalPaidAmount += $customer->TotalPaidAmount;
                    $totalDueAmount += $customer->PaymentDue;
                }

                // Calculate total expenses for vendors
                foreach ($vendors as $vendor) {
                    $totalExpenses += $vendor->TotalPaidAmount;
                }
            ?>

            <div class="row">
                <div class="col-xl-3 col-md-6">
                    <div class="card-box">
                        <div class="widget-chart-1">
                            <div class="widget-chart-box-1 float-left">
                                <i class="fa fa-dollar-sign dashboard-icon"></i>
                            </div>
                            <div class="widget-detail-1 text-right">
                                <h2 class="p-t-10 m-b-0"><?= number_format($totalSales, 2) ?></h2>
                                <p class="text-muted">Total Sales</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6" style="display: none;">
                    <div class="card-box">
                        <div class="widget-chart-1">
                            <div class="widget-chart-box-1 float-left">
                                <i class="fa fa-dollar-sign dashboard-icon"></i>
                            </div>
                            <div class="widget-detail-1 text-right">
                                <h2 class="p-t-10 m-b-0"><?= isset($todays_sales) ? number_format($todays_sales, 2) : '0.00'; ?></h2>
                                <p class="text-muted">Today Sales</p>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="col-xl-3 col-md-6">
                    <div class="card-box">
                        <div class="widget-chart-1">
                            <div class="widget-chart-box-1 float-left">
                                <i class="fa fa-wallet dashboard-icon"></i>
                            </div>
                            <div class="widget-detail-1 text-right">
                                <h2 class="p-t-10 m-b-0"><?= number_format($totalPaidAmount, 2) ?></h2>
                                <p class="text-muted">Total Received Amount</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6">
                    <div class="card-box">
                        <div class="widget-chart-1">
                            <div class="widget-chart-box-1 float-left">
                                <i class="fa fa-chart-line dashboard-icon"></i>
                            </div>
                            <div class="widget-detail-1 text-right">
                                <h2 class="p-t-10 m-b-0"><?= number_format($totalDueAmount, 2) ?></h2>
                                <p class="text-muted">Total Due</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6">
                    <div class="card-box">
                        <div class="widget-chart-1">
                            <div class="widget-chart-box-1 float-left">
                                <i class="fa fa-chart-line dashboard-icon"></i>
                            </div>
                            <div class="widget-detail-1 text-right">
                                <h2 class="p-t-10 m-b-0"><?= number_format($totalExpenses, 2) ?></h2>
                                <p class="text-muted">Total Expenses</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6">
                    <div class="card-box">
                        <div class="widget-chart-1">
                            <div class="widget-chart-box-1 float-left">
                                <i class="fa fa-wallet dashboard-icon"></i>
                            </div>
                            <div class="widget-detail-1 text-right">
                                <h2 class="p-t-10 m-b-0"><?= number_format($totalSales - $totalExpenses, 2) ?></h2>
                                <p class="text-muted">Net Profit</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6">
                    <div class="card-box">
                        <div class="widget-chart-1">
                            <div class="widget-chart-box-1 float-left">
                                <i class="fa fa-users dashboard-icon"></i>
                            </div>
                            <div class="widget-detail-1 text-right">
                                <h2 class="p-t-10 m-b-0"><?php echo $total_customers; ?></h2>
                                <p class="text-muted">Active Customers</p>
                            </div>
                        </div>
                    </div>
                </div>

            
         

            </div>
            <!-- End Metrics Cards -->


            <!-- Chart for Financial Overview -->
            <div class="row">
                <div class="col-xl-6">
                    <div class="card-box">
                        <h4 class="header-title m-t-0">Sales vs Expenses</h4>
                        <canvas id="financialOverviewChart" height="150"></canvas>

                    </div>
                </div>
            </div>

           

            <!-- Table for displaying details -->
       
        </div> <!-- container -->
    </div> <!-- content -->
</div> <!-- content-page -->

<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->

<?php $this->view('includes/footer_start.php') ?>
<!-- extra js start -->
<script src="<?= base_url('assets/js/Chart.bundle.min.js') ?>"></script>
<script src="<?= base_url('assets/js/jquery.dataTables.min.js') ?>"></script>
<script src="<?= base_url('assets/js/dashboard.js') ?>"></script>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>


<script>
    // Sales vs Expenses Chart
    const ctx = document.getElementById('financialOverviewChart').getContext('2d');
    const financialOverviewChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Sales', 'Expenses'],
            datasets: [{
                label: 'Amount',
                data: [<?= $totalSales ?>, <?= $totalExpenses ?>],
                backgroundColor: [
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(255, 99, 132, 0.2)'
                ],
                borderColor: [
                    'rgba(75, 192, 192, 1)',
                    'rgba(255, 99, 132, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>
<!-- extra js end -->
<?php $this->view('includes/footer_end.php') ?>
