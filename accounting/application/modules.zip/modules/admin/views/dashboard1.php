<?php $this->view('includes/header_start.php'); ?>
<!-- extra css start -->
<!-- extra css end -->
<?php $this->view('includes/header_end.php'); ?>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">

            <div class="row">
                <div class="col-xs-12">
                    <div class="page-title-box">
                        <h4 class="page-title">Dashboard</h4>
                        <ol class="breadcrumb p-0">
                            <li>
                                <a href="<?= base_url('admin') ?>"><?= title ?></a>
                            </li>
                            <li class="active">
                                Dashboard
                            </li>
                        </ol>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <!-- end row -->

           <!-- Table for displaying reload details on the dashboard -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card-box">
                            <h4 class="header-title m-t-0 m-b-30">Reload Details</h4>
                            
                            <div class="row">
                                <div class="col-lg-12 col-sm-12 col-xs-12 col-md-12 col-xl-12">
                                    <!-- Table for displaying reload details -->
                                    <?php if (isset($reloadRecords) && !empty($reloadRecords)): ?>
                                        <table>
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Date</th>
                                                    <th>VC</th>
                                                    <th>Provider</th>
                                                    <th>Package</th>
                                                    <th>Total Amount</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($reloadRecords as $record): ?>
                                                    <tr>
                                                        <td><?= $record->ReloadId ?></td>
                                                        <td><?= $record->CreatedDate ?></td>
                                                        <td><?= $record->Vc ?></td>
                                                        <td><?= $record->Provider ?></td>
                                                        <td><?= $record->Package ?></td>
                                                        <td><?= number_format($record->Package + $record->AddOn + $record->ExtraCharge, 2) ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    <?php else: ?>
                                        <p>No reload records found.</p>
                                    <?php endif; ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

<!-- Script to initialize DataTable on dashboard -->
<script>
$(document).ready(function () {
    $('#dashboard_reload_table').DataTable();
});
</script>


<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->

<?php $this->view('includes/footer_start.php') ?>
<!-- extra js start -->
<!-- extra js end -->
<?php $this->view('includes/footer_end.php') ?>
