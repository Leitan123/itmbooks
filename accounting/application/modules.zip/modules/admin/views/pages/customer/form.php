
<?php $this->view('includes/header_start.php'); ?>
<!-- extra css start -->
<!-- extra css end -->
<?php $this->view('includes/header_end.php'); ?>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<?php ?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="page-title-box">
                        <h4 class="page-title">Customer</h4>
                        <ol class="breadcrumb p-0">
                            <li><a href="<?= base_url('admin') ?>">Dashboard</a></li>
                            <li><a href="<?= base_url('admin/customer') ?>"> Customer</a></li>
                            <li class="active"> <?= empty($obj->CustomerId) ? "Create" : "Edit" ?> </li>
                        </ol>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <!-- end row -->

            <?php $this->view('includes/notification.php'); ?>

            <div class="row">
                <div class="col-sm-12">
                    <?= form_open() ?>
                    <div class="card-box">
                        <h4 class="header-title m-t-0 m-b-30">General Information</h4>

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <div class="row">

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="paymentDate">Date</label>
                                                <input required type="date" id="RegDate" name="form[RegDate]" class="form-control" 
                                                    value="<?= isset($obj->RegDate) ? htmlspecialchars($obj->RegDate) : date('Y-m-d') ?>">
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="name">#</label>
                                                <input readonly type="text" id="CustomerNo" name="form[CustomerNo]"
                                                       value="<?= set_value('form[CustomerNo]', $CustomerNo) ?>"
                                                       class="form-control">
                                                <?= form_error('form[CustomerNo]') ?>
                                            </div>
                                        </div>
                                    
                                        
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="name">Company Name</label>
                                                <input required type="text" id="CompanyName" name="form[CompanyName]"
                                                       value="<?= set_value('form[CompanyName]', $obj->CompanyName) ?>"
                                                       class="form-control">
                                                <?= form_error('form[CompanyName]') ?>
                                            </div>
                                        </div>
                                    

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="name">Customer Name</label>
                                                <input required type="text" id="CustomerName" name="form[CustomerName]"
                                                       value="<?= set_value('form[CustomerName]', $obj->CustomerName) ?>"
                                                       class="form-control">
                                                <?= form_error('form[CustomerName]') ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="name"> Phone No </label>
                                                    <input onkeyup="check_numaric(this.id)"  type="text" id="Phone" name="form[Phone]"
                                                       value="<?= set_value('form[Phone]', $obj->Phone) ?>"
                                                       class="form-control">
                                                <?= form_error('form[Phone]') ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="name"> Mobile No </label>
                                                    <input onkeyup="check_numaric(this.id)"  type="text" id="MobileNo" name="form[MobileNo]"
                                                       value="<?= set_value('form[MobileNo]', $obj->MobileNo) ?>"
                                                       class="form-control">
                                                <?= form_error('form[MobileNo]') ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="remark">Address</label>
                                                <textarea id="remark" name="form[Address]" class="form-control" rows="3"><?= isset($obj->Address) ? htmlspecialchars($obj->Address) : '' ?></textarea>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="CustomerType">Customer Type</label>
                                                <select id="CustomerType" name="form[CustomerType]" class="form-control">
                                                    <option value="COD" <?= isset($obj->CustomerType) && $obj->CustomerType === 'COD' ? 'selected' : '' ?>>COD</option>
                                                    <option value="Credit" <?= isset($obj->CustomerType) && $obj->CustomerType === 'Credit' ? 'selected' : '' ?>>Credit</option>
                                                </select>
                                                <?= form_error('form[CustomerType]') ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="CreditLimit">Credit Limit</label>
                                                <input type="number" id="CreditLimit" name="form[CreditLimit]"
                                                       value="<?= set_value('form[CreditLimit]', $obj->CreditLimit) ?>"
                                                       class="form-control" min="0" step="0.01">
                                                <?= form_error('form[CreditLimit]') ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="OpeningBalance">Opening Balance</label>
                                                <input type="number" id="OpeningBalance" name="form[OpeningBalance]"
                                                       value="<?= set_value('form[OpeningBalance]', $obj->OpeningBalance) ?>"
                                                       class="form-control" min="0" step="0.01">
                                                <?= form_error('form[OpeningBalance]') ?>
                                            </div>
                                        </div>


                                        <div class="col-lg-6" style="display: none">
                                            <div class="form-group">
                                                <label> Default Image
                                                    <small> image size ( 270px * 210px )</small>
                                                </label>
                                            </div>
                                            <div class="fileinput-button btn btn-success sepH_b">
                                                <i class="fa fa-plus"></i>
                                                <span> Add file </span>
                                                <input class="image_upload" data-for="#default_img_grid_upload"
                                                       data-name="Image" type="file" name="userfile">
                                            </div>
                                            <input type="hidden" name="form[Image]" value="">
                                            <ul class="img-grid2 img-grid  clearfix" id="default_img_grid_upload">
                                                <?php if ($obj->Image): ?>
                                                    <li>
                                                        <div class="upload_img_single thumbnail">
                                                            <img src="<?= UPT . $obj->Image ?>"
                                                                 class="thumbnail img-responsive" alt=""/>

                                                            <div class="upload_img_actions">
                                                                <span class=" fa fa-times pull-right btn  btn-danger  "
                                                                      onclick="image_upload.remove($(this))"> </span>
                                                                <a style="color: white"
                                                                   href="<?= UP . $obj->Image ?>"
                                                                   class="fa fa-search-plus pull-right btn  btn-success">
                                                                </a>
                                                                <input
                                                                    type="hidden" name="form[Image]"
                                                                    value="<?= $obj->Image ?>"></div>
                                                        </div>
                                                    </li>
                                                <?php endif; ?>
                                            </ul>
                                            <?= form_error('form[Image]') ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <button class="btn btn-success pull-right"> Save</button>

                    <?= form_close() ?>
                </div>
                <!-- end row -->
            </div>
        </div>
        <!-- end col -->
    </div>
    <!-- end row -->

</div>
<!-- container -->

</div>
<!-- content -->

</div>
<!-- End content-page -->



<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->

<?php $this->view('includes/footer_start.php') ?>
<!-- extra js start -->
<!-- multiupload -->
<script src="<?= base_url() ?>assets/plugins/jquery-ui/jquery.ui.widget.min.js"></script>
<script src="<?= base_url() ?>assets/plugins/jQuery-File-Upload/js/jquery.fileupload.js"></script>
<script src="<?= base_url() ?>assets/plugins/jQuery-File-Upload/js/jquery.iframe-transport.js"></script>
<script src="<?= base_url() ?>assets/plugins/jQuery-File-Upload/js/extras/load-image.min.js"></script>
<script src="<?= base_url() ?>assets/plugins/jQuery-File-Upload/js/jquery.fileupload-process.js"></script>
<script src="<?= base_url() ?>assets/plugins/jQuery-File-Upload/js/jquery.fileupload-image.js"></script>
<!-- magnific popup -->

<script src="<?= base_url() ?>assets/ckeditor/ckeditor.js"></script>


<script>
    function check_numaric(n){
        if (isNaN($('#'+n).val())) {
            if(n=="Days") {
                $('#' + n).val('1');

                $.ajax({
                    url: URL.base + CONTROLLER + "/get_settle_date/",
                    data: {
                        days: $("#Days").val(),
                    },
                    type: 'post',
                    //            dataType: 'json',
                    //            console.log(data)
                    success: function (data) {
                    alert(data);
                        $("#SettlementDate").val(data);
                    }
                });
            }
//            else if(n=="ContactNo") {
//                var data = $('#ContactNo').val();
//            else
//                if (data.Length != 10) {
//                    alert('ContactNo');
//                }
//            }
            else {
                $('#' + n).val('');
            }

        }else
        if(n=="Days") {
//           alert ($("#Days").val());
            $.ajax({
                url: URL.base + CONTROLLER + "/get_settle_date/",
                data: {
                    days: $("#Days").val(),
                },
                type: 'post',
                //            dataType: 'json',
                //            console.log(data)
                success: function (data) {
                    console.log(data);
//                    $("#SettlementDate").val(data);
                    var $datepicker = $('#datepicker');
                    $datepicker.datepicker();
                    $datepicker.datepicker('setDate', data);
                }
            });
        }

    }



    $(function () {
//        CKEDITOR.replace('description');
        image_upload.init();
        image_upload.default_image();
        image_upload.default_doc();
        $("#img_load").hide();
        $("#img_file").hide();

    });

    image_upload = {
        init: function () {
            if ($("#image_upload").length) {
                var e = $("<button/>").addClass("btn btn-success btn-block").prop("disabled", !0).text("Processing...").on("click", function (e) {
                    var a = $(this), i = a.data();
                    a.off("click").text("Abort").on("click", function () {
                        a.remove(), i.abort()
                    }), i.submit().always(function () {
                        a.remove()
                    }), e.preventDefault()
                });
                $("#image_upload").fileupload({
                    url: URL.base + CONTROLLER + "/do_upload/",
                    dataType: "json",
                    autoUpload: !1,
                    acceptFileTypes: /(\.|\/)(gif|jpe?g|png)$/i,
                    maxFileSize: 5e6,
                    disableImageResize: /Android(?!.*Chrome)|Opera/.test(window.navigator.userAgent),
                    previewMaxWidth: 220,
                    previewMaxHeight: 220,
                    previewCrop: !0
                }).on("fileuploadsubmit", function (e, a) {
                    var i = $("#image_upload");
                    return a.formData = {files: i.data(a)}, a.formData.files ? void 0 : (i.focus(), !1)
                }).on("fileuploadadd", function (a, i) {
                    i.context = $("<li/>").appendTo("#img_grid_upload"), $("#upload_progress").length || $("body").append('<div id="upload_progress"><i class="fa fa-spinner fa-spin"></i></div>'), $.each(i.files, function (a, o) {
                        var t = $('<div class="upload_img_actions">').wrapInner('<span class=" fa fa-times pull-right btn  btn-danger  " onclick="image_upload.remove($(this))" > </span>  '), n = $('<div class="upload_img_single thumbnail" />').append(t);
                        a || t.append(e.clone(!0).data(i)), n.appendTo(i.context)
                    })
                }).on("fileuploadprocessalways", function (e, a) {
                    var i = a.index, o = a.files[i], t = $(a.context.children()[i]);
                    o.preview && t.prepend(o.preview), o.error && t.find(".upload_img_actions").append($('<div class="alert alert-danger"/>').text(o.error)), i + 1 === a.files.length && a.context.find("button").text("Upload").prop("disabled", !!a.files.error)
                }).on("fileuploadprogressall", function (e, a) {
                    $("#upload_progress").addClass("show_progress");
                    var i = parseInt(a.loaded / a.total * 100, 10);
                    $("#upload_progress div").width(i + "%").html(i + "%");
                    100 == i && setTimeout("$('#upload_progress').removeClass('show_progress')", 500)
                }).on("fileuploaddone", function (e, a) {
                    $.each(a.result.files, function (e, i) {
                        i.url ? $(a.context.children()[e]).find(".upload_img_actions").append('<div class="alert alert-success">  Upload success <input type="hidden" name="image[]" value="' + i.name + '" > </div>') : i.error && $(a.context.children()[e]).find(".upload_img_actions").append($('<div class="alert alert-danger"/>').text(i.error))
                    })
                }).on("fileuploadfail", function (e, a) {
                    $("#upload_progress").addClass("show_progress"), $.each(a.files, function (e, i) {
                        $(a.context.children()[e]).find(".upload_img_actions").append($('<div class="alert alert-danger"/>').text("File upload failed."))
                    }), setTimeout("$('#upload_progress').removeClass('show_progress')", 500)
                }).prop("disabled", !$.support.fileInput).parent().addClass($.support.fileInput ? void 0 : "disabled")
            }
        }, remove: function (e) {
            confirm("Do you want to remove this file ") && e.closest("li").remove()
        },
        default_image: function () {
            var e = $("<button/>").addClass("btn btn-success btn-block").prop("disabled", !0).text("Processing...").on("click", function (e) {
                var a = $(this), i = a.data();
                a.off("click").text("Abort").on("click", function () {
                    a.remove(), i.abort()
                }), i.submit().always(function () {
                    a.remove()
                }), e.preventDefault()
            }), a = null;
            $(".image_upload").click(function () {
                a = $(this)
            }).fileupload({
                url: URL.base + CONTROLLER + "/do_upload/",
                dataType: "json",
                autoUpload: !1,
                acceptFileTypes: /(\.|\/)(gif|jpe?g|png)$/i,
                maxFileSize: 5e6,
                disableImageResize: /Android(?!.*Chrome)|Opera/.test(window.navigator.userAgent),
                previewMaxWidth: 220,
                previewMaxHeight: 220,
                previewCrop: !0
            }).on("fileuploadsubmit", function (e, a) {
                var i = $(".image_upload");
                return a.formData = {files: i.data(a)}, a.formData.files ? void 0 : (i.focus(), !1)
            }).on("fileuploadadd", function (i, o) {
                $(a.data("for")).html(" "), o.context = $("<li/>").appendTo(a.data("for")), $("#upload_progress").length || $("body").append('<div id="upload_progress"><i class="fa fa-spinner fa-spin"></i></div>'), $.each(o.files, function (a, i) {
                    var t = $('<div class="upload_img_actions">').wrapInner('<span class=" fa fa-times pull-right btn  btn-danger" onclick="image_upload.remove($(this))" > </span> '), n = $('<div class="upload_img_single thumbnail" />').append(t);
                    a || t.append(e.clone(!0).data(o)), n.appendTo(o.context)
                })
            }).on("fileuploadprocessalways", function (e, a) {
                var i = a.index, o = a.files[i], t = $(a.context.children()[i]);
                o.preview && t.prepend(o.preview), o.error && t.find(".upload_img_actions").append($('<div class="alert alert-danger"/>').text(o.error)), i + 1 === a.files.length && a.context.find("button").text("Upload").prop("disabled", !!a.files.error)
            }).on("fileuploadprogressall", function (e, a) {
                $("#upload_progress").addClass("show_progress");
                var i = parseInt(a.loaded / a.total * 100, 10);
                $("#upload_progress div").width(i + "%").html(i + "%");
                100 == i && setTimeout("$('#upload_progress').removeClass('show_progress')", 500)
            }).on("fileuploaddone", function (e, i) {
                $.each(i.result.files, function (e, o) {
                    o.url ? $(i.context.children()[e]).find(".upload_img_actions").append('<div class="alert alert-success">Upload success <br/><input type="hidden" name="form[' + a.data("name") + ']" value="' + o.name + '" > </div>') : o.error && $(i.context.children()[e]).find(".upload_img_actions").append($('<div class="alert alert-danger"/>').text(o.error))
                })
            }).on("fileuploadfail", function (e, a) {
                $("#upload_progress").addClass("show_progress"), $.each(a.files, function (e, i) {
                    $(a.context.children()[e]).find(".upload_img_actions").append($('<div class="alert alert-danger"/>').text("File upload failed."))
                }), setTimeout("$('#upload_progress').removeClass('show_progress')", 500)
            }).prop("disabled", !$.support.fileInput).parent().addClass($.support.fileInput ? void 0 : "disabled")
        },
        default_doc: function () {
            $('#doc_upload').fileupload({
                url: URL.base + CONTROLLER + "/do_doc_upload/",
                dataType: "json",
                autoUpload: 1,
                acceptFileTypes: /(\.|\/)(pdf)$/i,
                maxFileSize: 5e6,
                disableImageResize: /Android(?!.*Chrome)|Opera/.test(window.navigator.userAgent),
                previewCrop: !0
            }).on("fileuploadsubmit", function (e, a) {
//                console.log('fileuploadsubmit');
                $("#img_load").show();
            }).on("fileuploadadd", function (i, o) {
//                console.log('fileuploadadd');
                $("#img_load").show();
            }).on("fileuploadprocessalways", function (e, a) {
//                console.log('fileuploadprocessalways');
                $("#img_load").show();
            }).on("fileuploadprogressall", function (e, a) {
//                console.log('fileuploadprogressall');
                $("#img_load").hide();
            }).on("fileuploaddone", function (e, i) {
                $("#document_file").val(i.result);
//                    console.log(i.result);
                $(".inner").html("<a href='<?= base_url('media/doc/') ?>" + i.result + "' target='_black'><img id='img_file' src='https://cdn3.iconfinder.com/data/icons/line-icons-set/128/1-02-48.png' /></a><span class=' fa fa-times pull-right btn  btn-danger' onclick='image_upload.removedoc($(this))'> </span>");


            }).on("fileuploadfail", function (e, a) {
                $("#document_file").val(i.result);
                console.log(i.result);
                $("#img_file").hide();
                $('.inner').html("<b style='color: red'>Invalid File Type or File Upload Fail</b>");
            });
        }, removedoc: function (e) {
            confirm("Do you want to remove this file ") && $('.inner').html('') , $("#document_file").val(""), $("#img_file").hide();
        }
    }

</script>

<!-- extra js end -->
<?php $this->view('includes/footer_end.php') ?>
