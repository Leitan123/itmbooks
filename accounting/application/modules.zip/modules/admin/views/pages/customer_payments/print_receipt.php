<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Receipt</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            width: 298px; /* Fixed width for printed receipt */
        }
        .container {
            width: 100%;
            max-width: 298px;
            margin: 0 auto;
            padding: 0;
            text-align: center;
        }
        .header, .footer {
            text-align: center;
            margin-bottom: 10px;
        }
        .header img {
            max-width: 80px; /* Adjust logo size */
            margin-bottom: 5px;
        }
        .header h1 {
            font-size: 18px; /* Adjusted font size for POS printer */
            margin: 0;
        }
        .details, .footer {
            text-align: left;
            font-size: 12px; /* Reduced font size for better fitting */
        }
        .details .row {
            display: flex;
            justify-content: space-between;
            margin: 3px 0; /* Reduced margin for compact design */
        }
        .description {
            border-top: 1px dashed #333;
            padding-top: 5px;
            font-size: 12px;
        }
        .description table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        .description table tr:nth-child(odd) {
            background-color: #f9f9f9;
        }
        .description table td {
            padding: 2px 0;
            font-size: 12px; /* Reduced font size for POS printer */
        }
        .footer p {
            font-size: 10px; /* Smaller font size for footer */
        }
        .total {
            font-weight: bold;
            margin-top: 5px;
            border-top: 1px dashed #333;
            padding-top: 5px;
        }
        /* Print Styles */
        @media print {
            body, .container {
                width: 100%;
                height: auto;
                margin: 0;
                padding: 0;
            }
            .footer {
                page-break-after: always;
            }
            button {
                display: none;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <img src="<?= base_url ("media/images") ?>/logo.png" alt="Company Logo"> <!-- Replace 'logo.png' with the path to your logo -->
        <h1>Jayatha Holdings (Pvt) Ltd</h1>
        <p>#22B Quarry Road, Colombo - 12.<br/>
        Contact No: +94 112 323 224 /  +94 702 662 274</p>
        <p><strong>Receipt</strong></p>
    </div>

    <div class="details">
        <div class="row">
            <span>Receipt No.:</span> <span><?= $customer_payments->PaymentID; ?></span>
        </div>
        <div class="row">
            <span>Date:</span> <span><?= date('Y-m-d'); ?></span>
        </div>
        <div class="row">
            <span>Customer:</span> <span><?= $customer_payments->CustomerName; ?></span>
        </div>
        <div class="row">
            <span>Payment Method:</span> <span><?= $customer_payments->PaymentMethod; ?></span>
        </div>
    </div>

    <div class="description">
        <table>
            <tr>
                <td>Description</td>
                <td>Amount</td>
            </tr>
            <tr>
                <td>Pay Amount</td>
                <td><?= number_format($customer_payments->PaidAmount, 2); ?></td>
            </tr>
        </table>
    </div>

    <div class="details">
        <div class="row total">
            <span>Paid Amount:</span> <span><?= number_format($customer_payments->PaidAmount, 2); ?></span>
        </div>
    </div>

    <div class="details">
        <div class="row">
            <span>Due Amount:</span> <span><?= number_format($customer_payments->PaymentDue, 2); ?></span>
        </div>
    </div>

    <div class="footer">
        <p><strong>THANK YOU - COME AGAIN</strong></p>
    </div>

    <button onclick="window.print()">Print</button>
</div>

</body>
</html>
