<?php $this->view('includes/header_start.php'); ?>
<!-- extra css start -->
<!-- extra css end -->
<?php $this->view('includes/header_end.php'); ?>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<?php ?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="page-title-box">
                        <h4 class="page-title">Item</h4>
                        <ol class="breadcrumb p-0">
                            <li><a href="<?= base_url('admin') ?>">Dashboard</a></li>
                            <li><a href="<?= base_url('admin/items') ?>">Items</a></li>
                            <li class="active"><?= empty($obj->ItemID) ? "Create" : "Edit" ?></li>
                        </ol>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <!-- end row -->

            <?php $this->view('includes/notification.php'); ?>

            <div class="row">
                <div class="col-sm-12">
                    <?= form_open() ?>
                    <div class="card-box">
                        <h4 class="header-title m-t-0 m-b-30">Item Information</h4>

                        <div class="row">

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="CategoryID">Category</label>
                                    <select id="CategoryID" name="form[CategoryID]" class="form-control">
                                        <option value="">Select Category</option>
                                        <?php foreach ($categories as $category): ?>
                                            <option value="<?= $category->CategoryID ?>" <?= ($obj->CategoryID == $category->CategoryID) ? 'selected' : '' ?>>
                                                <?= $category->CategoryName ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="BrandID">Brand</label>
                                    <select id="BrandID" name="form[BrandID]" class="form-control">
                                        <option value="">Select Brand</option>
                                        <!-- Brands will be loaded here via AJAX -->
                                    </select>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="ItemName">Item Name</label>
                                    <input type="text" id="ItemName" name="form[ItemName]" 
                                           value="<?= set_value('form[ItemName]', $obj->ItemName) ?>" 
                                           class="form-control">
                                    <?= form_error('form[ItemName]') ?>
                                </div>
                            </div>

                            
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="ItemDescription">Description</label>
                                    <textarea id="ItemDescription" name="form[ItemDescription]" 
                                              rows="5" class="form-control"><?= set_value('form[ItemDescription]', $obj->ItemDescription) ?></textarea>
                                    <?= form_error('form[ItemDescription]') ?>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="PurchasePrice">Purchase Price</label>
                                    <input type="text" id="PurchasePrice" name="form[PurchasePrice]" 
                                           value="<?= set_value('form[PurchasePrice]', $obj->PurchasePrice) ?>" 
                                           class="form-control">
                                    <?= form_error('form[PurchasePrice]') ?>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="SellingPrice">Selling Price</label>
                                    <input type="text" id="SellingPrice" name="form[SellingPrice]" 
                                           value="<?= set_value('form[SellingPrice]', $obj->SellingPrice) ?>" 
                                           class="form-control">
                                    <?= form_error('form[SellingPrice]') ?>
                                </div>
                            </div>

                            <!--

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="Stock">Opening Stock</label>
                                    <input type="number" id="Stock" name="form[Stock]" 
                                           value="<?= set_value('form[Stock]', $obj->Stock) ?>" 
                                           class="form-control">
                                    <?= form_error('form[Stock]') ?>
                                </div>
                            </div>

                        -->

                        </div>
                    </div>

                    <button class="btn btn-success pull-right">Save</button>

                    <?= form_close() ?>
                </div>
                <!-- end row -->
            </div>
        </div>
        <!-- end col -->
    </div>
    <!-- end row -->
</div>
<!-- container -->

</div>
<!-- content -->

</div>
<!-- End content-page -->

<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->

<?php $this->view('includes/footer_start.php') ?>
<!-- extra js start -->

<script type="text/javascript">
    $(document).ready(function () {
        var selectedCategory = $('#CategoryID').val();
        var selectedBrand = "<?= $obj->BrandID ?>"; // Get the selected BrandID

        function loadBrands(categoryID, selectedBrand) {
            if (categoryID) {
                $.ajax({
                    url: '<?= base_url('admin/Items/get_brands_by_category') ?>',
                    type: 'POST',
                    data: { category_id: categoryID },
                    success: function (response) {
                        var brands = JSON.parse(response);
                        $('#BrandID').empty();
                        $('#BrandID').append('<option value="">Select Brand</option>');

                        $.each(brands, function (index, brand) {
                            var selected = (brand.BrandID == selectedBrand) ? 'selected' : '';
                            $('#BrandID').append('<option value="' + brand.BrandID + '" ' + selected + '>' + brand.BrandName + '</option>');
                        });
                    }
                });
            } else {
                $('#BrandID').empty();
                $('#BrandID').append('<option value="">Select Brand</option>');
            }
        }

        // Trigger when Category changes
        $('#CategoryID').change(function () {
            var categoryID = $(this).val();
            loadBrands(categoryID, null); // Load brands based on selected category
        });

        // Load brands on page load if editing an item
        if (selectedCategory) {
            loadBrands(selectedCategory, selectedBrand);
        }
    });

</script>


<!-- extra js end -->
<?php $this->view('includes/footer_end.php') ?>
