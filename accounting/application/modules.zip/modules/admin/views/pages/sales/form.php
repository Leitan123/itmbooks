<?php $this->view('includes/header_start.php'); ?>
<!-- extra css start -->
<!-- extra css end -->
<?php $this->view('includes/header_end.php'); ?>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="page-title-box">
                        <h4 class="page-title">Sales</h4>
                        <ol class="breadcrumb p-0">
                            <li><a href="<?= base_url('admin') ?>">Dashboard</a></li>
                            <li><a href="<?= base_url('admin/Sales') ?>">Sales</a></li>
                            <li class="active"><?= isset($obj) ? "Edit Sale" : "Add Sale" ?></li>
                        </ol>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <!-- end row -->

            <?php $this->view('includes/notification.php'); ?>

            <div class="row">
                <div class="col-sm-12">
                    <?= form_open() ?>
                    <div class="card-box">
                        <h4 class="header-title m-t-0 m-b-30" style="display: flex; justify-content: space-between; align-items: center;">
                            <div style="font-weight: bold;"><?= isset($obj) ? "Edit Sale" : "Add Sale" ?></div>
                            <div style="display: flex; gap: 20px; align-items: center;">
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <label for="CustomerType" style="margin: 0;">Customer Type:</label>
                                    <input type="text" id="CustomerType" class="form-control" style="width: 150px;" readonly>
                                </div>
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <label for="CreditLimit" style="margin: 0;">Credit Limit:</label>
                                    <input type="text" id="CreditLimit" class="form-control" style="width: 150px;" readonly>
                                </div>
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <label for="CreditBalance" style="margin: 0;">Credit Balance:</label>
                                    <input type="text" id="CreditBalance" class="form-control" style="width: 150px;" readonly>
                                </div>
                            </div>
                        </h4>

                            
                            <div class="form-group">
                        
                                    <label for="sale_date">Sale Date</label>
                                    <input type="date" id="saleDate" name="form[SaleDate]" class="form-control" value="<?= isset($obj->SaleDate) ? htmlspecialchars($obj->SaleDate) : date('Y-m-d') ?>" required>

                             
                            </div>

                            <div class="form-group">
                                    <div class="form-group">
                                        <label for="customer_select">Customer</label>
                                        <select name="form[CustomerId]" id="customer_select" class="form-control select2">
                                            <option value="">-- Select Customer --</option>
                                            <?php foreach ($customers as $customer): ?>
                                                <option value="<?= $customer->CustomerId ?>" <?= (isset($sale->CustomerId) && $customer->CustomerId == $sale->CustomerId) ? 'selected' : '' ?>>
                                                    <?= $customer->CustomerName ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                            </div>

                            

                            <div id="items-container">
                                <?php if (isset($obj->items) && is_array($obj->items)): ?>
                                    <?php foreach ($obj->items as $index => $item): ?>
                                        <div class="row item-row">
                                            <input type="hidden" name="form[items][<?= $index ?>][ItemID]" value="<?= $item->ItemID ?>">

                                            <div class="col-lg-5">
                                                <div class="form-group">
                                                    <label for="ItemID">Item</label>
                                                    <select name="form[items][<?= $index ?>][ItemID]" class="form-control select2 ItemID" id="ItemID_0" required>
                                                        <option value="">Select Item</option>
                                                        <?php foreach ($items as $item): ?>
                                                            <option value="<?= $item->ItemID ?>">
                                                                <?= $item->CategoryName ?> | <?= $item->BrandName ?> | <?= $item->ItemName ?>
                                                            </option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-lg-1">
                                                <div class="form-group">
                                                    <label for="Quantity">Qty / Kgs</label>
                                                    <input type="number" step="0.01" name="form[items][<?= $index ?>][Quantity]" 
                                                           class="form-control Quantity" value="<?= $item->Quantity ?>" required>
                                                </div>
                                            </div>

                                            <div class="col-lg-2">
                                                <div class="form-group">
                                                    <label for="SalePrice">Sale Price</label>
                                                    <input type="number" name="form[items][<?= $index ?>][SalePrice]" 
                                                           class="form-control SalePrice" value="<?= $item->SalePrice ?>" required>
                                                </div>
                                            </div>

                                            <div class="col-lg-2">
                                                <div class="form-group">
                                                    <label for="TotalAmount">Amount</label>
                                                    <input type="text" name="form[items][<?= $index ?>][TotalAmount]" 
                                                           class="form-control TotalAmount" value="<?= $item->TotalAmount ?>" readonly>
                                                </div>
                                            </div>

                                            <div class="col-lg-1">
                                                <div class="form-group">
                                                    <label>&nbsp;</label>
                                                    <button type="button" class="btn btn-danger remove-item" style="width: 100%;">Remove</button>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="row item-row">
                                        <div class="col-lg-5">
                                            <div class="form-group">
                                                <label for="ItemID">Item</label>
                                                <select name="form[items][0][ItemID]" class="form-control select2 ItemID" id="ItemID_0" required>
                                                    <option value="">Select Item</option>
                                                    <?php foreach ($items as $item): ?>
                                                        <option value="<?= $item->ItemID ?>">
                                                            <?= $item->CategoryName ?> | <?= $item->BrandName ?> | <?= $item->ItemName ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-1">
                                            <div class="form-group">
                                                <label for="Quantity">Qty / Kgs</label>
                                                <input type="number" step="0.01" name="form[items][0][Quantity]" class="form-control Quantity" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-2">
                                            <div class="form-group">
                                                <label for="SalePrice">Sale Price</label>
                                                <input type="number" name="form[items][0][SalePrice]" class="form-control SalePrice" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-2">
                                            <div class="form-group">
                                                <label for="TotalAmount">Amount</label>
                                                <input type="text" name="form[items][0][TotalAmount]" class="form-control TotalAmount" readonly>
                                            </div>
                                        </div>
                                        <div class="col-lg-1">
                                            <div class="form-group">
                                                <label>&nbsp;</label>
                                                <button type="button" class="btn btn-danger remove-item" style="width: 100%;">Remove</button>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>


                            <button type="button" class="btn btn-success add-item" style="margin-top: 15px;">Add Item</button>
                            <hr>

                            <div class="form-group">
                                <label for="TotalSaleAmount">Total Amount</label>
                                <input type="text" id="TotalSaleAmount" class="form-control" readonly>
                            </div>

                            <button type="submit" class="btn btn-primary">Submit</button>

                       

                    </div>

                    <?= form_close() ?>
                </div>
                <!-- end row -->
            </div>

        </div>
        <!-- end col -->
    </div>
    <!-- end row -->
</div>
<!-- container -->

</div>
<!-- content -->

</div>
<!-- End content-page -->

<?php $this->view('includes/footer_start.php'); ?>


<script type="text/javascript">
    $('#customer_select').change(function () {
        var customerId = $(this).val();

        if (customerId) {
            $.ajax({
                url: '<?= base_url("admin/Sales/get_customer_details") ?>',
                type: 'POST',
                data: { customerId: customerId },
                dataType: 'json',
                success: function (data) {
                    if (data && !data.error) {
                        $('#CustomerType').val(data.CustomerType);
                        $('#CreditLimit').val(
                            parseFloat(data.CreditLimit).toLocaleString('en-US', {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2
                            })
                        );
                        $('#CreditBalance').val(
                            parseFloat(data.CreditBalance).toLocaleString('en-US', {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2
                            })
                        );
                    } else {
                        alert('Error: ' + (data.error || 'No data found!'));
                        $('#CustomerType').val('');
                        $('#CreditLimit').val('0.00');
                        $('#CreditBalance').val('0.00');
                    }
                },
                error: function () {
                    alert('Failed to fetch customer details.');
                    $('#CustomerType').val('');
                    $('#CreditLimit').val('0.00');
                    $('#CreditBalance').val('0.00');
                }
            });
        } else {
            $('#CustomerType').val('');
            $('#CreditLimit').val('0.00');
            $('#CreditBalance').val('0.00');
        }
    });
</script>




<script type="text/javascript">
    $(document).ready(function () {
        function calculateTotal(row) {
            var quantity = parseFloat(row.find('.Quantity').val()) || 0;
            var salePrice = parseFloat(row.find('.SalePrice').val()) || 0;
            var totalAmount = quantity * salePrice;
            row.find('.TotalAmount').val(totalAmount.toFixed(2));
            calculateGrandTotal();
        }

        function calculateGrandTotal() {
            var grandTotal = 0;
            $('.TotalAmount').each(function () {
                grandTotal += parseFloat($(this).val()) || 0;
            });
            $('#TotalSaleAmount').val(grandTotal.toFixed(2));
        }

        // Add item row
        $('.add-item').click(function() {
            var index = $('#items-container .item-row').length;
            var newRow = getNewItemRow(index);
            $('#items-container').append(newRow);
        });

        // Function to generate a new item row
        function getNewItemRow(index) {
            return `
                <div class="row item-row">
                    <div class="col-lg-5">
                        <div class="form-group">
                            <label for="ItemID">Item</label>
                            <select name="form[items][${index}][ItemID]" class="form-control select2" required>
                                <option value="">Select Item</option>
                                <?php foreach ($items as $item): ?>
                                    <option value="<?= $item->ItemID ?>">
                                        <?= $item->CategoryName ?> | <?= $item->BrandName ?> | <?= $item->ItemName ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-1">
                        <div class="form-group">
                            <label for="Quantity">Qty</label>
                            <input type="number" step="0.01" name="form[items][${index}][Quantity]" class="form-control Quantity" required>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="form-group">
                            <label for="SalePrice">Sale Price</label>
                            <input type="number" name="form[items][${index}][SalePrice]" class="form-control SalePrice" required>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="form-group">
                            <label for="TotalAmount">Amount</label>
                            <input type="text" name="form[items][${index}][TotalAmount]" class="form-control TotalAmount" readonly>
                        </div>
                    </div>
                    <div class="col-lg-1">
                        <div class="form-group">
                            <label>&nbsp;</label>
                            <button type="button" class="btn btn-danger remove-item" style="width: 100%;">Remove</button>
                        </div>
                    </div>
                </div>
            `;
        }

        // Remove item row
        $(document).on('click', '.remove-item', function () {
            $(this).closest('.item-row').remove();
            calculateGrandTotal();
        });

        // Calculate total on input change
        $(document).on('input', '.Quantity, .SalePrice', function () {
            var row = $(this).closest('.item-row');
            calculateTotal(row);
        });

        // Calculate total for each item
        $('.Quantity, .SalePrice').on('input', function () {
            var row = $(this).closest('.item-row');
            calculateTotal(row);
        });

        $('.Quantity').on('input', function () {
            var row = $(this).closest('.item-row');
            var quantity = parseFloat(row.find('.Quantity').val()) || 0;
            var salePrice = parseFloat(row.find('.SalePrice').val()) || 0;
            var totalAmount = quantity * salePrice;
            row.find('.TotalAmount').val(totalAmount.toFixed(2)); // Ensure TotalAmount is displayed with 2 decimals
        });


        
    });
</script>

<?php $this->view('includes/footer_end.php'); ?>
