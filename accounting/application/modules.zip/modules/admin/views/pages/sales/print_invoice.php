<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jayatha Holdings (Pvt) Ltd</title>
    <style>
        /* Global Styles */
        body {
            font-family: 'Helvetica Neue', Arial, sans-serif;
            margin: 0;
            padding: 0;
            color: #333;
        }

        /* Container */
        .container {
            max-width: 210mm; /* A4 width */
            margin: 20px auto;
            padding: 20px;
            box-sizing: border-box;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #f9f9f9;
        }

        /* Header */
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        .header img {
            max-width: 120px;
            height: auto;
        }
        .header h1 {
            font-size: 24px;
            margin: 10px 0;
            color: #333;
        }
        .header p {
            font-size: 14px;
            margin: 3px 0;
            color: #555;
        }
        .header .invoice-type {
            font-weight: bold;
            font-size: 18px;
            color: #007bff;
        }

        /* Details Section */
        .details {
            display: flex;
            justify-content: space-between;
            margin-bottom: 30px;
        }
        .details .section {
            font-size: 14px;
            color: #555;
        }
        .details .section span {
            font-weight: bold;
            color: #333;
        }

        /* Items Table */
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        .items-table th, .items-table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            font-size: 14px;
        }
        .items-table th {
            background-color: #f4f4f4;
            font-weight: bold;
        }
        .items-table td {
            background-color: #fff;
        }

        /* Total Section */
        .total {
            font-size: 16px;
            font-weight: bold;
            display: flex;
            justify-content: flex-end;
            margin-top: 20px;
        }
        .total span {
            padding-left: 20px;
            font-size: 18px;
        }

        /* Footer */
        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 12px;
            color: #777;
        }
        .footer p {
            margin: 5px 0;
        }

        /* Print Styles */
        @media print {
            body, .container {
                width: 100%;
                margin: 0;
                padding: 0;
            }
            .header img {
                max-width: 100px;
            }
            .header h1 {
                font-size: 22px;
            }
            .items-table th, .items-table td {
                padding: 8px;
                font-size: 12px;
            }
            .total span {
                font-size: 16px;
                font-weight: bold;
            }
            .container {
                width: 100%;
                margin: 0;
                padding: 10mm;
                box-sizing: border-box;
                border-radius: 0;
                background-color: #fff;
                border: none;
            }
            button {
                display: none;
            }
            .footer {
                page-break-after: always;
                margin-top: 15px;
            }
        }

    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <img src="<?= base_url("media/images") ?>/logo.png" alt="Company Logo"> <!-- Replace 'logo.png' with the path to your logo -->
        <h1>Jayatha Holdings (Pvt) Ltd</h1>
        <p>#22B Quarry Road, Colombo - 12.<br/>Contact No: +94 112 323 224 / +94 702 662 274</p>
        <p class="invoice-type">Sales Invoice</p>
    </div>

    <!-- Details Section -->
    <div class="details">
        <div class="section">
            <p><span>Invoice No.:</span> <?= isset($sales->SaleID) ? $sales->SaleID : 'N/A' ?></p>
            <p><span>Date:</span> <?= isset($sales->SaleDate) ? date('d M Y', strtotime($sales->SaleDate)) : 'N/A' ?></p>
            <p><span>Customer:</span> <?= isset($sales->CustomerName) ? $sales->CustomerName : 'N/A' ?></p>
        </div>
        <div class="section">
            <!-- Add any additional details you might need here (e.g., payment terms, billing address) -->
        </div>
    </div>

    <!-- Items Table -->
    <table class="items-table">
        <thead>
            <tr>
                <th>No</th>
                <th>Description</th>
                <th>Qty</th>
                <th>Unit Price</th>
                <th>Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($sales->items)): ?>
                <?php 
                    $itemNames = explode(',', $sales->ItemNames);
                    $quantities = explode(',', $sales->Quantities);
                    $prices = explode(',', $sales->Prices);
                    $totalAmount = 0;
                ?>
                <?php for ($i = 0; $i < count($itemNames); $i++): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td><?= htmlspecialchars(trim($itemNames[$i])) ?></td>
                        <td><?= isset($quantities[$i]) ? htmlspecialchars(trim($quantities[$i])) : 0 ?></td>
                        <td><?= isset($prices[$i]) ? number_format(trim($prices[$i]), 2) : '0.00' ?></td>
                        <td>
                            <?php 
                                $amount = isset($quantities[$i]) && isset($prices[$i]) ? trim($quantities[$i]) * trim($prices[$i]) : 0; 
                                $totalAmount += $amount; 
                                echo number_format($amount, 2);
                            ?>
                        </td>
                    </tr>
                <?php endfor; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" style="text-align: center;">No items found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Total Section -->
    <div class="total">
        <span>Total Amount: <?= number_format($totalAmount, 2) ?></span>
    </div>

    <!-- Footer -->
    <div class="footer">
        <p><strong>THANK YOU FOR SHOPPING WITH US!</strong></p>
        <p>If you have any questions, please contact us at +94 112 323 224 or email info@jayatha.lk</p>
    </div>

    <!-- Print Button -->
    <button onclick="window.print()">Print Invoice</button>
</div>

</body>
</html>
