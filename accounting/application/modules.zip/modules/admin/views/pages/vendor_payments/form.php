<?php $this->view('includes/header_start.php'); ?>
<!-- extra css start -->
<!-- extra css end -->
<?php $this->view('includes/header_end.php'); ?>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="page-title-box">
                        <h4 class="page-title">Vendor Payment</h4>
                        <ol class="breadcrumb p-0">
                            <li><a href="<?= base_url('admin') ?>">Dashboard</a></li>
                            <li><a href="<?= base_url('admin/vendor_payments') ?>">Vendor Payments</a></li>
                            <li class="active"><?= empty($obj->PaymentID) ? "Create" : "Edit" ?></li>
                        </ol>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <!-- end row -->

            <?php $this->view('includes/notification.php'); ?>

            <div class="row">
                <div class="col-sm-12">
                    <?= form_open() ?>
                    <div class="card-box">
                        <h4 class="header-title m-t-0 m-b-30">Payment Details</h4>

                        <div class="row">
                            <!-- Vendor Field -->
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="vendor_select">Vendor</label>
                                    <select name="form[VendorID]" id="vendor_select" class="form-control select2">
                                        <option value="">-- Select Vendor --</option>
                                        <?php foreach ($vendors as $vendor): ?>
                                            <option value="<?= $vendor->VendorID ?>"><?= $vendor->VendorName ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>


                            <!-- Payment Date Field -->
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="paymentDate">Payment Date</label>
                                    <input type="date" id="paymentDate" name="form[PaymentDate]" class="form-control" 
                                        value="<?= isset($obj->PaymentDate) ? htmlspecialchars($obj->PaymentDate) : date('Y-m-d') ?>">
                                </div>
                            </div>

                            <!-- Payment Due Field -->
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="paymentDue">Payment Due</label>
                                    <input required type="number" id="paymentDue" name="form[PaymentDue]" class="form-control" 
                                        value="<?= isset($obj->PaymentDue) ? htmlspecialchars($obj->PaymentDue) : '0.00' ?>" 
                                        step="0.01" min="0" readonly> <!-- Set readonly since it's updated via AJAX -->
                                </div>
                            </div>

                            <!-- Paid Amount Field -->
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="paidAmount">Paid Amount</label>
                                    <input type="number" id="paidAmount" name="form[PaidAmount]" class="form-control" required>
                                </div>
                            </div>

                            
                            <!-- Payment Method Field -->
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="paymentMethod">Payment Method</label>
                                    <select id="paymentMethod" name="form[PaymentMethod]" class="form-control">
                                        <option value="">Select Payment Method</option>
                                        <option value="Cash" <?= isset($obj->PaymentMethod) && $obj->PaymentMethod === 'Cash' ? 'selected' : '' ?>>Cash</option>
                                        <option value="Card" <?= isset($obj->PaymentMethod) && $obj->PaymentMethod === 'Card' ? 'selected' : '' ?>>Card</option>
                                        <option value="Bank Transfer" <?= isset($obj->PaymentMethod) && $obj->PaymentMethod === 'Bank Transfer' ? 'selected' : '' ?>>Bank Transfer</option>
                                        <option value="Cheque" <?= isset($obj->PaymentMethod) && $obj->PaymentMethod === 'Cheque' ? 'selected' : '' ?>>Cheque</option>
                                    </select>
                                    <?= form_error('form[PaymentMethod]') ?>
                                </div>
                            </div>

                            <!-- Cheque Fields (initially hidden) -->
                            <div id="chequeFields" style="display: none;">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="chequeNumber">Cheque Number</label>
                                        <input type="text" id="chequeNumber" name="form[ChequeNumber]" class="form-control" 
                                               value="<?= isset($obj->ChequeNumber) ? htmlspecialchars($obj->ChequeNumber) : '' ?>">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="chequeDate">Cheque Date</label>
                                        <input type="date" id="chequeDate" name="form[ChequeDate]" class="form-control" 
                                               value="<?= isset($obj->ChequeDate) ? htmlspecialchars($obj->ChequeDate) : '' ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-success pull-right">Save</button>

                    <?= form_close() ?>
                </div>
                <!-- end row -->
            </div>
        </div>
        <!-- end col -->
    </div>
    <!-- end row -->
</div>
<!-- container -->

<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->

<?php $this->view('includes/footer_start.php') ?>
<!-- extra js start -->

<script>
    $(document).ready(function() {
        $('#vendor_select').change(function() {
            var vendorId = $(this).val();
            if (vendorId) {
                $.ajax({
                    url: '<?= base_url("admin/Vendor_payments/get_total_due_amount/") ?>' + vendorId,
                    method: 'GET',
                    success: function(response) {
                        try {
                            var data = JSON.parse(response);
                            $('#paymentDue').val(data.PaymentDue || 0); // Update Payment Due field
                        } catch (e) {
                            console.error('Error parsing response:', e);
                            console.error('Raw response:', response); // Log raw response for debugging
                            $('#paymentDue').val(0); // Reset in case of error
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error:', error);
                        alert('Error fetching payment due amount. Please try again.');
                        $('#paymentDue').val(0);
                    }
                });
            } else {
                $('#paymentDue').val(0); // Reset when no vendor is selected
            }
        });
    });
</script>

<script>

// Show/hide cheque fields based on payment method
$('#paymentMethod').change(function() {
    if ($(this).val() === 'Cheque') {
        $('#chequeFields').show();
        $('#chequeNumber').prop('required', true);
        $('#chequeDate').prop('required', true);
    } else {
        $('#chequeFields').hide();
        $('#chequeNumber').prop('required', false);
        $('#chequeDate').prop('required', false);
    }
});

// Trigger the change event on page load in case Cheque is already selected
$('#paymentMethod').trigger('change');

$(document).ready(function() {
    $('#vendor_select').change(function() {
        var vendorId = $(this).val();
        if (vendorId) {
            $.ajax({
                url: '<?= base_url("admin/Vendor_payments/get_total_due_amount/") ?>' + vendorId,
                method: 'GET',
                success: function(response) {
                    try {
                        var data = JSON.parse(response);
                        $('#paymentDue').val(data.PaymentDue || 0); // Update Payment Due field
                    } catch (e) {
                        console.error('Error parsing response:', e);
                        console.error('Raw response:', response); // Log raw response for debugging
                        $('#paymentDue').val(0); // Reset in case of error
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', error);
                    alert('Error fetching payment due amount. Please try again.');
                    $('#paymentDue').val(0);
                }
            });
        } else {
            $('#paymentDue').val(0); // Reset when no vendor is selected
        }
    });
});

</script>

<!-- extra js end -->
<?php $this->view('includes/footer_end.php') ?>
